library(ggplot2)
library(dplyr)
library(tidyr)

theme_grant <- function() {
  theme_classic(base_size = 10) +
    theme(
      plot.title = element_text(face = "bold"),
      plot.caption = element_text(size = 8),
      legend.position = "bottom"
    )
}

plot_framework <- function() {
  dat <- data.frame(
    x = c(1, 2, 3),
    y = c(1, 1, 1),
    label = c("Aim 1\nTheory", "Aim 2\nMethod", "Aim 3\nValidation")
  )

  ggplot(dat, aes(x, y, label = label)) +
    geom_label(size = 4) +
    geom_segment(
      aes(x = x[-length(x)] + .25,
          xend = x[-1] - .25,
          y = y[-length(y)],
          yend = y[-1]),
      inherit.aes = FALSE,
      arrow = arrow(length = unit(0.15, "inches"))
    ) +
    xlim(.5, 3.5) +
    ylim(.7, 1.3) +
    theme_void()
}

plot_aim1_simulation <- function() {
  set.seed(123)
  dat <- expand.grid(
    n = c(100, 250, 500),
    signal = c("Low", "Moderate", "High"),
    replicate = 1:100
  )

  dat$rmse <- 1 / sqrt(dat$n) *
    ifelse(dat$signal == "Low", 1.4,
           ifelse(dat$signal == "Moderate", 1.0, .7)) *
    abs(rnorm(nrow(dat)))

  summary_dat <- dat |>
    group_by(n, signal) |>
    summarize(rmse = mean(rmse), .groups = "drop")

  ggplot(summary_dat, aes(n, rmse, group = signal)) +
    geom_line() +
    geom_point() +
    labs(x = "Sample size", y = "RMSE", linetype = NULL) +
    theme_grant()
}

plot_aim2_performance <- function() {
  dat <- data.frame(
    method = c("Existing A", "Existing B", "Proposed"),
    estimate = c(.72, .81, .93),
    lower = c(.64, .73, .87),
    upper = c(.80, .89, .98)
  )

  ggplot(dat, aes(x = estimate, y = reorder(method, estimate))) +
    geom_errorbarh(aes(xmin = lower, xmax = upper), height = .15) +
    geom_point(size = 2) +
    labs(x = "Performance metric", y = NULL) +
    theme_grant()
}

plot_aim3_workflow <- function() {
  dat <- data.frame(
    x = c(1, 2, 3, 4),
    y = 1,
    label = c("Data", "Model", "Validation", "Scientific\ninference")
  )

  ggplot(dat, aes(x, y, label = label)) +
    geom_label(size = 3.5) +
    geom_segment(
      aes(x = x[-length(x)] + .25,
          xend = x[-1] - .25,
          y = y[-length(y)],
          yend = y[-1]),
      inherit.aes = FALSE,
      arrow = arrow(length = unit(0.15, "inches"))
    ) +
    xlim(.5, 4.5) +
    ylim(.7, 1.3) +
    theme_void()
}

plot_preliminary <- function() {
  set.seed(321)
  dat <- data.frame(
    x = seq(0, 10, length.out = 100)
  )
  dat$y <- 0.5 * dat$x + rnorm(100, sd = 1)

  ggplot(dat, aes(x, y)) +
    geom_point(size = 1.3) +
    geom_smooth(method = "lm", se = TRUE) +
    labs(
      x = "Predictor",
      y = "Outcome"
    ) +
    theme_grant()
}
