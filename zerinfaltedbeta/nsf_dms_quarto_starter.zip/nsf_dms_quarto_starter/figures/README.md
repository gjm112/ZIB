Generated figures can be stored here when they need
to be versioned independently of Quarto. Figures generated directly by
Quarto/R chunks do not need to be stored here.
